﻿function start() {
    var x = 100;
    var storlek = 50;

    circle(x, 150, storlek, "green");
    circle(x + 100, 150, storlek, "blue");
    circle(x + 200, 150, storlek, "red");
    circle(x + 300, 150, storlek, "yellow");
}