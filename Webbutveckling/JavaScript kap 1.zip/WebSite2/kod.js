﻿function start() {
    rectangle(0, 0, 800, 400, "blue");
    rectangle(0, 250, 800, 200, "lime");
    circle(10, 30, 120, "yellow");
    var x = 200
    var storlek = 30
    circle(x, 100, storlek, "white");
    circle(x + 30, 100, storlek + 10, "white");
    circle(x + 60, 100, storlek + 10, "white");
    circle(x + 90, 100, storlek, "white");
    circle(x + 300, 100, storlek, "white");
    circle(x + 330, 100, storlek + 10, "white");
    circle(x + 360, 100, storlek + 10, "white");
    circle(x + 390, 100, storlek, "white");
    rectangle(300, 150, 250, 200, "red");
    triangle(300, 150, 550, 150, 425, 30, "darkred");
    rectangle(320, 170, 62, 62, "lightblue");
    rectangle(470, 170, 62, 62, "lightblue");
    line(320, 201, 382, 201, 2, "black");
    line(351, 170, 351, 233, 2, "black");
    line(470, 201, 532, 201, 2, "black");
    line(500, 170, 500, 233, 2, "black");
    rectangle(390, 250, 75, 100, "brown");
    line(390, 250, 390, 350, 1, "black");
    line(465, 250, 465, 350, 1, "black");
    line(390, 250, 465, 250, 1, "black");
    line(391, 300, 401, 300, 3, "gold");
}