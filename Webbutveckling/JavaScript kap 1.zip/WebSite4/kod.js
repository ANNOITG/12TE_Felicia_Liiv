﻿function start() {
    ring(400, 400, 300, 10, "red");
    ring(400, 400, 291, 10, "orange");
    ring(400, 400, 282, 10, "yellow");
    ring(400, 400, 273, 10, "green");
    ring(400, 400, 264, 10, "blue");
    ring(400, 400, 255, 10, "purple");
    ring(400, 400, 200, 10, "red");
    ring(400, 400, 191, 10, "orange");
    ring(400, 400, 182, 10, "yellow");
    ring(400, 400, 173, 10, "green");
    ring(400, 400, 164, 10, "blue");
    ring(400, 400, 155, 10, "purple");
}