﻿function start() {
    var color1 = prompt("Hejsan hejsan! Välkommen till brottsregistret! Vilken hurfärg hade mördaren, använd färgpalettkod!");
    var color2 = prompt("Vilken ögonfärg hade mördaren?");
    var color3 = prompt("vilken färg hade hans mun?");
    circle(400, 200, 200, color1);
    circle(300, 100, 30, color2);
    circle(500, 100, 30, color2);
    triangle(300, 200, 400, 100, 500, 200, "#DCCE9E");
    circle(400, 300, 50, color3);
}