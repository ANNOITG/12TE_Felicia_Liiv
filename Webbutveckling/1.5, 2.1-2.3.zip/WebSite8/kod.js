﻿function start() {
    var password = prompt("Hej och välkommen! Vänligen skriv i ditt lösenord.");
    if (password == "feliciaisbest") {
        text("Välkommen Felicia!", 0, 100, "black", 20);
        text("Du visste väl att hemligheten är att du är ganska söt?", 0, 130, "black", 20);
    }
    else {
        text("Lösenordet var tyvärr fel.", 0, 100, "black", 20);
        text("Ingen hemlighet för dig!", 0, 130, "black", 20);
    }
}