﻿function start() {
    var color1 = prompt("Hej! Skriv en snygg färg på en bil, typ röd eller varför inte grön?");
    var color2 = prompt("Snyggt! skriv in en ny färg som är snygg på däck, svart eller brun kanske?");
    rectangle(400, 200, 300, 150, color1);
    rectangle(700, 350, 200, -80, color1);
    circle(465, 350, 50, color2);
    circle(650, 350, 50, color2);
}