﻿function start()
{
    if (confirm("Skulle du vilja se en triangel?")) {
        triangle(200, 100, 50, 75, 90, 120, "green");
        text("Här har du en triangel!" ,50, 150, "black", 20);
    }
    else {
        triangle(200, 100, 50, 75, 90, 120, "green");
        triangle(100, 200, 75, 50, 120, 90, "blue");
        text("Too bad, här är 2 trianglar!", 50, 220, "black", 20);
    }
}