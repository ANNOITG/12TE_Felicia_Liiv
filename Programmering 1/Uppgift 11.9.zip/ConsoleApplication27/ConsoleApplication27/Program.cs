﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication27
{
    class Program
    {
        static int CelsiusToFahrenheit(int celsius)
        {
            double fahrenheit = CTF(celsius);
            return (int)fahrenheit;
        }
        static float CelsiusToFahrenheit(float celsius)
        {
            double fahrenheit = CTF(celsius);
            return (float)fahrenheit;
        }
        private static double CTF(double C)
        {
            double fahrenheit = ((C * 9) / 5) + 32;
            return fahrenheit;
        }
        static int FahrenheitToCelsius(int fahrenheit)
        {
            double celsius = FTC(fahrenheit);
            return (int)celsius;
        }
        static float FahrenheitToCelsius(float fahrenheit)
        {
            double celsius = FTC(fahrenheit);
            return (int)celsius;
        }
        private static double FTC(double F)
        {
            double celsius = ((F - 32) * 5) / 9;
            return celsius;
        }
        
        static void Main(string[] args)
        {
            int fahrenheitI = CelsiusToFahrenheit(100);
            Console.WriteLine("100 grader celsius blir: " + fahrenheitI + " i fahrenheit.");

            float fahrenheitF = CelsiusToFahrenheit(0f);
            Console.WriteLine("0 grader celsius blir: " + fahrenheitF + " i fahrenheit.");

            int celsiusI = FahrenheitToCelsius(0);
            Console.WriteLine("0 grader fahrenheit blir: " + celsiusI + " i celsius.");

            float celsiusF = FahrenheitToCelsius(100f);
            Console.WriteLine("100 grader fahrenheit blir: " + celsiusF + " i celsius.");

            Console.ReadKey();
        }
    }
}
